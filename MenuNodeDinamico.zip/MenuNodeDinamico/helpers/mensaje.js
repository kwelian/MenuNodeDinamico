const { stdout } = require('process');

require('colors');

const mostrarMenu = () => {
    return new Promise(resolve =>{
        console.clear();
        console.log("================================".green);
        console.log("     Seleccione una opcion".blue);
        console.log("================================\n".green);

        console.log(`${'1'.red} Crear carpetas`);
        console.log(`${'2'.red} Listar tareas`);
        console.log(`${'3'.red} Listar tareas completadas`);
        console.log(`${'4'.red} Listar tareas pendientes`);
        console.log(`${'5'.red} Completar tarea(s)`);
        console.log(`${'6'.red} Borrar tareas`);
        console.log(`${'0'.red} Salir\n`);

        const readline = require('readline').createInterface({
            input: process.stdin,
            output: process.stdout
        })
        
        readline.question('Seleccione una opcion: ', (opt)=>{
            readline.close();
            resolve(opt);
        })
    })
}


module.exports = {
    mostrarMenu
}