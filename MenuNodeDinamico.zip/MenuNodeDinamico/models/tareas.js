const Tarea = require("./tarea");

class Tareas {
    _listado = {};

    get listadoArr() {
        const listado = [];
        Object.keys(this._listado).forEach(key => {
            const tarea = this._listado[key];
            listado.push(tarea);
        });
        return listado;
    }

    constructor() {
        this._listado = {};
    }

    crearTarea(desc = '') {
        const tarea = new Tarea(desc);
        this._listado[tarea.id] = tarea;
    }

    listarTareasCompletadas() {
        const completadas = this.listadoArr.filter(tarea => tarea.completadoEn !== null);
        completadas.forEach((tarea, index) => {
            console.log(`${index + 1}. ${tarea.desc} :: ${'Completada'.green}`);
        });
    }

    listarTareasPendientes() {
        const pendientes = this.listadoArr.filter(tarea => tarea.completadoEn === null);
        pendientes.forEach((tarea, index) => {
            console.log(`${index + 1}. ${tarea.desc} :: ${'Pendiente'.red}`);
        });
    }

    borrarTarea(id = '') {
        if (this._listado[id]) {
            delete this._listado[id];
        }
    }
    
}

module.exports = Tareas;
