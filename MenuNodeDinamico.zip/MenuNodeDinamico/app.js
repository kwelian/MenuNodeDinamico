require('colors');

const { guardarBD } = require('./helpers/guardarArchivo');
const { inquireMenu, pausa, leerInput } = require('./helpers/inquirer');
const Tareas = require('./models/tareas');

const main = async () => {
   let opt = '';
   const tareas = new Tareas();

   do {
      opt = await inquireMenu();

      switch (opt) {
         case '1':
            const desc = await leerInput('Descripcion: ');
            tareas.crearTarea(desc);
            break;

         case '2':
            console.log("Listado de tareas:");
            tareas.listadoArr.forEach((tarea, index) => {
               const estado = tarea.completadoEn ? 'Completada'.green : 'Pendiente'.red;
               console.log(`${index + 1}. ${tarea.desc} :: ${estado}`);
            });
            break;

         case '3':
            console.log("Listado de tareas completadas:");
            tareas.listarTareasCompletadas();
            break;

         case '4':
            console.log("Listado de tareas pendientes:");
            tareas.listarTareasPendientes();
            break;

         case '5':
            const ids = await leerInput('Ingrese el ID de la tarea (separado por comas): ');
            const idsArray = ids.split(',').map(id => id.trim());
            tareas.completarTarea(idsArray);
            console.log('Tarea(s) completada(s)');
            break;

         case '6':
            const idBorrar = await leerInput('Ingrese el ID de la tarea a borrar: ');
            tareas.borrarTarea(idBorrar);
            console.log('Tarea borrada');
            break;

         default:
            break;
      }

      guardarBD(tareas.listadoArr);

      await pausa();
   } while (opt !== '0');
}

main();
